import subprocess
import os

def deploy_to_vercel(project_path):
    try:
        os.chdir(project_path)
        result = subprocess.run(["vercel", "--prod"], capture_output=True, text=True)
        return result.stdout
    except Exception as e:
        return f"Deployment failed: {e}"
