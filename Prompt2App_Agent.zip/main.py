from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
import os

os.environ["OPENAI_API_KEY"] = "your-api-key-here"

prompt = PromptTemplate(
    input_variables=["user_prompt"],
    template="""
You are a senior full-stack developer AI. Based on the prompt below, generate a complete, clean, production-ready app code. 
Choose the best tech stack automatically (React, Node, Firebase, Flutter, etc.), and generate:
- A structured explanation
- Full frontend + backend code
- Optional chatbot or AI integration

Prompt:
{user_prompt}

Return results in this structure:
1. Explanation of what is being built
2. Tech stack used
3. Frontend code
4. Backend code
5. Extra notes (e.g. deployment tips)
"""
)

llm = OpenAI(temperature=0.3)
chain = LLMChain(llm=llm, prompt=prompt)
