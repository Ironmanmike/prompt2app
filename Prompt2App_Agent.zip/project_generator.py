import os
import shutil
import re

def save_code_blocks(text_output, project_dir):
    if os.path.exists(project_dir):
        shutil.rmtree(project_dir)
    os.makedirs(project_dir)

    code_blocks = re.findall(r'```(.*?)\n(.*?)```', text_output, re.DOTALL)
    for i, (lang, code) in enumerate(code_blocks):
        ext = { "js": ".js", "jsx": ".jsx", "html": ".html", "css": ".css", "py": ".py" }.get(lang.strip(), ".txt")
        with open(os.path.join(project_dir, f"file_{i+1}{ext}"), "w") as f:
            f.write(code.strip())
