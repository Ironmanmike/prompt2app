import streamlit as st
from main import chain
from project_generator import save_code_blocks
from deploy_to_vercel import deploy_to_vercel
from push_to_github import push_to_github

st.set_page_config(page_title="Prompt2App", layout="wide")
st.title("🧠 Prompt2App — Generate & Deploy Full Apps with AI")

user_prompt = st.text_area("Describe the app you want to build:", height=200)

if st.button("Build & Deploy"):
    with st.spinner("Generating app..."):
        result = chain.run(user_prompt)
        st.code(result, language='markdown')
        save_code_blocks(result, "generated_project")
        deploy_url = deploy_to_vercel("generated_project")
        push_to_github("generated_project", "prompt2app-generated", "Built with Prompt2App", private=False)
        st.success("✅ App Deployed and Pushed to GitHub!")
        st.markdown(f"🔗 [View your app on Vercel]({deploy_url})")
