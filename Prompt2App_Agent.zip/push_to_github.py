import os
import subprocess

def push_to_github(project_dir, repo_name, description="", private=False):
    os.chdir(project_dir)

    subprocess.run(["git", "init"], check=True)
    subprocess.run(["git", "add", "."], check=True)
    subprocess.run(["git", "commit", "-m", "Initial commit"], check=True)

    visibility = "private" if private else "public"
    subprocess.run([
        "gh", "repo", "create", repo_name,
        "--" + visibility,
        "--description", description,
        "--source=.",
        "--remote=origin",
        "--push"
    ], check=True)
